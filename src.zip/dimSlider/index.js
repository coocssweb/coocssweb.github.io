import DimSlider from './DimSlider';

export default DimSlider;
