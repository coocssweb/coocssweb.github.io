/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-21 12:07:24
 * Copyright © Leedarson. All rights reserved.
 */

import styled, { css } from 'styled-components';
import { getOpacityColor } from '../styledUtils';

const StyledSlider = styled.div`
  position: relative;
  width: 100%;
  display: inline-block;

  ${({ theme }) => css`
    height: ${theme.pxToRem(10)};
  `}
`;

const StyledRail = styled.div`
  position: absolute;
  width: 100%;
  box-sizing: border-box;

  ${({ theme }) => css`
    background-color: ${getOpacityColor(theme, '#376CC2', 0.2)};
    height: ${theme.pxToRem(10)};
    border-radius: ${theme.pxToRem(5)};
  `}
`;

const StyledTrack = styled.div`
  position: absolute;
  left: 0;
  background-color: #376cc2;
  width: 100%;
  transform-origin: 0 0;

  ${({ theme, percent }) => css`
    height: ${theme.pxToRem(12)};
    border-radius: ${theme.pxToRem(12)};
    width: ${percent * 100}%;
  `}
`;

const StyledHandle = styled.div`
  box-sizing: border-box;
  border-radius: 50%;
  background-color: #fff;
  box-shadow: 0 0 4px rgba(0, 0, 0, 0.2);
  outline: none;
  cursor: pointer;
  transition: 0.2s transform ease;

  ${({ theme, disabled }) => css`
    margin-left: ${theme.pxToRem(-22)};
    margin-top: ${theme.pxToRem(-22)};
    width: ${theme.pxToRem(50)};
    height: ${theme.pxToRem(50)};

    ${!disabled &&
      css`
        &:active {
          box-shadow: 0 0 6px rgba(0, 0, 0, 0.2);
          transform: scale(1.2);
        }
      `}

    ${disabled &&
      css`
        background-color: #eee;
      `}
  `}
`;

export { StyledSlider, StyledRail, StyledTrack, StyledHandle };
