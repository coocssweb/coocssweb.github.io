/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-21 12:07:19
 * Copyright © Leedarson. All rights reserved.
 */

import React, { useCallback, useState, useEffect, useMemo, useRef } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { StyledSlider, StyledRail, StyledTrack, StyledHandle } from './StyledSlider';
import { Drag } from '../gesture';
import Tooltip from '../tooltip';

const StyledDrag = styled(Drag)`
  float: left;
`;

const Slider = React.memo(({ format, min, max, defaultValue, disabled, tooltip, onChange }) => {
  const containerRef = useRef();
  const [rect, setRect] = useState([]);
  const [haveCalculated, setHaveCalculated] = useState(false);
  const [offset, setOffset] = useState([50, 0]);
  const [percent, setPercent] = useState(0);
  const [value, setValue] = useState(defaultValue);
  const [tooltipVisible, setTooltipVisible] = useState(false);
  const denominator = useMemo(() => max - min, [max, min]);

  useEffect(() => {
    if (!containerRef.current) {
      return;
    }
    const containerRect = containerRef.current.getBoundingClientRect();
    const { width, height } = containerRect;
    // 可用区域的宽度
    const finalWidth = width;
    const finalHeight = height;
    setRect([finalWidth, finalHeight]);
  }, [denominator]);

  /**
   * 计算：初始颜色，操作点位置
   */
  useEffect(() => {
    const calculate = () => {
      const [width] = rect;
      let left = (width * (defaultValue - min)) / denominator;
      left = Math.max(0, left);
      left = Math.min(width, left);

      setOffset([left, 0]);
      setPercent(left / rect[0]);
      setHaveCalculated(true);
    };

    const ensureRect = rect.length === 2 && rect[0] > 0;
    const ensureValue = defaultValue >= min && defaultValue <= max;
    if (ensureRect && ensureValue && !haveCalculated) {
      calculate();
    }
  }, [defaultValue, denominator, haveCalculated, max, min, rect]);

  const handleDragStart = useCallback(() => {
    setTooltipVisible(true);
  }, []);

  const handleDrag = useCallback(
    ([left]) => {
      setPercent(left / rect[0]);
      setOffset([left, 0]);
      const changeValue = parseInt((left / rect[0]) * denominator, 10);
      setValue(changeValue + min);
      // onChange(changeValue + min);
    },
    [denominator, min, onChange, rect],
  );

  const handleDragEnd = useCallback(() => {
    setTooltipVisible(false);
  }, []);

  const Handle = tooltip ? (
    <StyledDrag
      onDragStart={handleDragStart}
      onDrag={handleDrag}
      onDragEnd={handleDragEnd}
      offset={offset}
      direction="x"
      bounds={[0, rect[0], 0, 0]}
      disabled={disabled}
    >
      <Tooltip value={format.replace('{value}', value)} visible trigger="hover" placement="top">
        <StyledHandle disabled={disabled} />
      </Tooltip>
    </StyledDrag>
  ) : (
    <StyledDrag
      onDragStart={handleDragStart}
      onDrag={handleDrag}
      onDragEnd={handleDragEnd}
      offset={offset}
      direction="x"
      bounds={[0, rect[0], 0, 0]}
      disabled={disabled}
    >
      <StyledHandle disabled={disabled} />
    </StyledDrag>
  );

  return (
    <StyledSlider ref={containerRef}>
      <StyledRail className="LdsSlider-rail" />
      <StyledTrack percent={percent} className="LdsSlider-track" />
      {haveCalculated ? Handle : null}
    </StyledSlider>
  );
});

Slider.prefixCls = 'LdsSlider';

Slider.defaultProps = {
  min: 0,
  max: 100,
  format: '{value}%',
  defaultValue: 0,
  disabled: false,
  tooltip: false,
  onChange: () => {},
};

Slider.propTypes = {
  min: PropTypes.number,
  max: PropTypes.number,
  format: PropTypes.string,
  defaultValue: PropTypes.number,
  disabled: PropTypes.bool,
  tooltip: PropTypes.bool,
  onChange: PropTypes.func,
};

export default Slider;
