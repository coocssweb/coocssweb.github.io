/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-08-21 12:07:14
 * Copyright © Leedarson. All rights reserved.
 */

import Slider from './Slider';

export default Slider;
