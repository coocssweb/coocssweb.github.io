/*
 * @Author: wangjiaxin@leedarson.com
 * @Date: 2019-09-09 10:32:49
 * Copyright © Leedarson. All rights reserved.
 */

import CctSlider from './CctSlider';

export default CctSlider;
